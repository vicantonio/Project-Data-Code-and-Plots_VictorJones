Jail Inmates in 2015	
	
This zip archive contains tables in individual  .csv spreadsheets	
from Jail Inmates in 2015, NCJ 250394  The full report including text	
and graphics in pdf format is available from: http://www.bjs.gov/index.cfm?ty=pbdetail&iid=6003	

	
Filename	Table title
 ji15t01.csv	Table 1. Inmates confined in local jails, average daily population, and incarceration rates, midyear 2000 and 2005�2015; yearend 2015
 ji15t02.csv	Table 2. Number of annual admissions to local jails, 1999 and 2007�2015
 ji15t03.csv	Table 3. Number of confined inmates in local jails, by characteristics, midyear 2000, 2005, and 2010�2014; yearend 2015
 ji15t04.csv	Table 4. Percent of confined inmates in local jails, by characteristics, midyear 2000, 2005, and 2010�2014; yearend 2015
 ji15t05.csv	Table 5. Mean and proportion of the average daily jail population, by size of jurisdiction, 2014 and 2015
 ji15t06.csv	Table 6. Rated capacity of local jails and percent of capacity occupied, 2000 and 2005�2015
 ji15t07.csv	Table 7. Percent of jail capacity occupied based on average daily population, by size of jurisdiction, 2014 and 2015
 ji15t08.csv	Table 8. Average daily jail population, admissions, and turnover rate, by size of jurisdiction, 2014 and 2015
 ji15t09.csv	Table 9. Persons under jail supervision, by confinement status, 2000 and 2006�2015
 ji15t10.csv	Table 10. Staff employed in local jails, by sex, December 2013 and 2015
	
Figure	
ji15f01	Figure 1. Average daily population of inmates confined in local jails, 2000 and 2005�2015
ji15f02	Figure 2. Midyear custody population, average daily population, and rated capacity in local jails, 2000�2015
	
Appendix tables	
ji15at01.csv	Appendix Table 1. Standard errors for table 1: Inmates confined in local jails, average daily population, and incarceration rates, midyear 2000 and 2005�2015; yearend 2015
ji15at02.csv	Appendix Table 2. Standard errors for table 2: Number of annual admissions to local jails, 1999 and 2007-2015
ji15at03.csv	Appendix Table 3. Standard errors for table 3: Number of confined inmates in local jails, by characteristics, midyear 2000, 2005, and 2010�2014; yearend 2015
ji15at04.csv	Appendix Table 4. Standard errors for table 4: Percent of confined inmates in local jails, by characteristics, midyear 2000, 2005, and 2010�2014; yearend 2015
ji15at05.csv	Appendix Table 5. Standard errors for table 5: Mean and proportion of the average daily jail population, by size of jurisdiction, 2014 and 2015
ji15at06.csv	Appendix Table 6. Standard errors for table 6: Rated capacity of local jails and percent of capacity occupied, 2000 and 2005�2015
ji15at07.csv	Appendix Table 7. Standard errors for table 7: Percent of jail capacity occupied, by size of jurisdiction, 2014 and 2015
ji15at08.csv	Appendix Table 8. Standard errors for table 8: Average daily jail population, admissions, and turnover rate, by size of jurisdiction, 2014 and 2015
ji15at09.csv	Appendix Table 9. Standard errors for table 9: Persons under jail supervision, by confinement status, 2000 and 2006�2015
ji15at10.csv	Appendix Table 10. Standard errors for table 10: Staff employed in local jails, by sex, December 2013 and 2015
