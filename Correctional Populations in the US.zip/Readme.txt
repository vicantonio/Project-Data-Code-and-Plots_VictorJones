Correctional Populations in the United States 2015	
	
This zip archive contains tables in individual  .csv spreadsheets	
from Correctional Populations in the United States 2015- Bulletin,  NCJ 250374  The full report including text	
and graphics in pdf format is available from: http://www.bjs.gov/index.cfm?ty=pbdetail&iid=5870	
	
This report is one in a series.  More recent editions may be available.  To view a list of all in the series go to	
http://www.bjs.gov/index.cfm?ty=pbse&sid=5	
	
Filename	Table title
cpus15t01	Table 1. Number of persons supervised by U.S. adult correctional systems, by correctional status, 2000 and 2005-2015
cpus15t02	Table 2. Number of persons supervised by U.S. adult correctional systems, by correctional status, 2007 and 2015
cpus15t03	Table 3. Change in the number of persons supervised by U.S. adult correctional systems, 2007-2015
cpus15t04	Table 4. Rate of persons supervised by U.S. adult correctional systems, by correctional status, 2000 and 2005-2015
cpus15t05	Table 5. Number of offenders with multiple correctional statuses at yearend, by correctional status, 2000-2015
	
Figure	
cpus15f01	Figure 1. Total population under the supervision of U.S. adult correctional systems and annual percent change, 2000-2015
	
Appendix tables	
cpus15at01	Appendix Table 1. Estimated number and rate of persons supervised by U.S. adult correctional systems, by jurisdiction and correctional status, 2015
cpus15at02	Appendix Table 2. Number and rate of persons supervised by U.S. adult correctional systems, by sex and jurisdiction, 2014 and 2015
cpus15at03	Appendix Table 3. Number and rate of persons supervised by U.S. adult correctional systems, by sex, correctional status, and jurisdiction, 2015
cpus15at04	Appendix Table 4. Number and rate of persons supervised by U.S. adult correctional systems, by sex and correctional status, 2014
cpus15at05	Appendix Table 5. Number of persons incarcerated by other adult correctional systems, 2000, 2010, and 2014-2015
cpus15at06	Appendix Table 6. Persons held in custody in state or federal prisons or in local jails, 2000, 2010, and 2014-2015
cpus15at07	Appendix Table 7. Standard errors for local jail inmates at midyear, 2005-2015
