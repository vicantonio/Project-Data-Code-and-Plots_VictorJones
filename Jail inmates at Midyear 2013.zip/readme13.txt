Jail Inmates at Midyear 2013-Statistical Tables NCJ 245350	
	
This zip archive contains tables in individual .csv spreadsheets	
Jail Inmates at Midyear 2013-Statistical Tables NCJ 245350	
The full report including text and graphics in .pdf format are available from:	
http://www.bjs.gov/index.cfm?ty=pbdetail&iid=4988
	
This report is one in a series. More recent editions may be available. To 	
"view a list of all in the series go to the 
view a list of all in the series go to the http://www.bjs.gov/index.cfm?ty=pbse&sid=38"	
 	
Tables	
jim13stt01.csv	Table 1: Inmates confined in local jails at midyear, average daily population, and incarceration rates, 2000�2013
jim13stt02.csv	Table 2: Number of inmates in local jails, by characteristics, midyear 2000 and 2005�2013
jim13stt03.csv	Table 3: Percent of inmates in local jails, by characteristics, midyear 2000 and 2005�2013
jim13stt04.csv	Table 4: Inmates confined in local jails at midyear, by size of jurisdiction, 2012�2013
jim13stt05.csv	Table 5: Rated capacity of local jails and percent of capacity occupied, 2000�2013
jim13stt06.csv	Table 6: Percent of jail capacity occupied at midyear, by size of jurisdiction, 2012�2013
jim13stt07.csv	Table 7: Average daily jail population, admissions, and turnover rate, by size of jurisdiction, week ending June 30, 2012 and 2013
jim13stt08.csv	Table 8: Inmate population in jail jurisdictions reporting on confined persons being held for U.S. Immigration and Customs Enforcement (ICE), midyear 2002�2013
jim13stt09.csv	Table 9: Persons under jail supervision, by confinement status and type of program, midyear 2000 and 2006�2013
	
Appendix Tables	
jim13stat01.csv	Appendix table 1: Standard errors for selected jail populations, 2012�2013
jim13stat02.csv	Appendix table 2: Standard errors for table 2: Number of inmates in local jails, by characteristics, midyear 2000 and 2005�2013
jim13stat03.csv	Appendix table 3: Standard error ratio estimates for table 3: Percent of inmates in local jails, by characteristics, midyear 2000 and 2005�2013
jim13stat04.csv	Appendix table 4: Standard errors for table 4: Inmates confined in local jails at midyear, by size of jurisdiction, 2012�2013
jim13stat05.csv	Appendix table 5: Standard errors for table 6: Percent of jail capacity occupied at midyear, by size of jurisdiction, 2012�2013
jim13stat06.csv	Appendix table 6: Standard errors for table 7: Average daily jail population, admissions, and turnover rate, by size of jurisdiction, week ending June 30, 2012 and 2013
jim13stat07.csv	Appendix table 7: Standard errors for table 9: Persons under jail supervision, by confinement status and type of program, midyear 2000 and 2006�2013
	
Figures	
jim13stf01.csv	Figure 1: Inmates confined in local jails at midyear and percent change in the jail population, 2000�2013
jim13stf02.csv	Figure 2: California's confined jail population, 1999 and 2005-2013
jim13stf03.csv	Figure 3: Midyear custody population, average daily population, and rated capacity in local jails, 2000�2013
jim13stf04.csv	Figure 4: Percent change in the midyear custody population and rated capacity between 2008 and 2013
